#include "Scheduler.h"

Scheduler::Scheduler() : useCore1(false) {}

void Scheduler::schedule(Token& token) {
    // Topological scheduling simulation
    Serial.println("Scheduling token...");
}

void Scheduler::enableMulticore() {
    useCore1 = true;
    multicore_launch_core1([](){ while(1); });
}