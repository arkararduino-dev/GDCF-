#ifndef UTILITIES_H
#define UTILITIES_H

#include <Arduino.h>

namespace GDCFUtils {
    void printTokenInfo(const Token& t);
    uint32_t getPerformanceCounter();
}

#endif